var total = 10

let num1 = 4
let num2 = 3

function soma (n1, n2){
    return n1 + n2
}

function sub(n1, n2){
    return n1 - n2
}

function mult(n1, n2){
    return n1 * n2
}

function div(n1, n2){
    return n1 / n2
}

console.log(soma(3,5))